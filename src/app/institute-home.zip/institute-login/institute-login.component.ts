import { Component } from '@angular/core';
import { InstituteSService } from '../institute-s.service';
import { Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
@Component({
  selector: 'app-institute-login',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './institute-login.component.html',
  styleUrl: './institute-login.component.css'
})
export class InstituteLoginComponent {
  loginForm: FormGroup;
 
  constructor(
    private fb: FormBuilder,
    private loginService: InstituteSService ,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      code: ['', Validators.required],
      password: ['', Validators.required]
    });
  }
 
  onSubmit() {
    if (this.loginForm.valid) {
      const loginRequest = this.loginForm.value;
 
      this.loginService.login(loginRequest).subscribe(
        response => {
          const instituteCode = this.loginForm.get('code')?.value;
          this.router.navigate(['/instituteH', instituteCode]); // Navigate to InstituteHomepageComponent with institute code
        },
        error => {
          alert('Invalid credentials!'); // Display error message
        }
      );
    } else {
      alert('Form is invalid');
      this.loginForm.markAllAsTouched(); // Highlight all invalid fields
    }
  }
}
